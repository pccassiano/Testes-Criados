<html>
<body>	
	<table border="1">
	<?php
		$a = $_POST["N1"];
		$cont = 1;
		while($cont <= 10)
		{	
			$r = $cont * $a;
			echo "<tr><td>" . $cont ."</td>";
			echo "<td>".$a."</td><td>" . $r ."</td>";
			echo "</tr>";
			$cont = $cont + 1; 
		}
	?>
	</table>
	</body>
</html>	