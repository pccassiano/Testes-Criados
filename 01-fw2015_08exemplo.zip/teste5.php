<html>
	<body>
	<?php
		$n1 = $_REQUEST["a"];	
		$n2 = $_REQUEST["b"];
		$r = $n1 + $n2;
		echo $r;
	?>
	</body>
</html>	
